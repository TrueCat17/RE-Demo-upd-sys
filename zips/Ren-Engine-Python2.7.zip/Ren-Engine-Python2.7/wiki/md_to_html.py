#!/usr/bin/env -S python3 -B

import os
import shutil

md_dir = 'md'
html_dir = 'html'

def processing(path):
	old_path = path
	
	path = path[len(md_dir):]
	if path[0] in '/\\':
		path = path[1:]
	
	name = os.path.basename(path)
	dir = path[:-len(name)]
	
	new_dir = os.path.join(html_dir, dir)
	new_path = os.path.join(new_dir, name)
	if not os.path.exists(new_dir):
		os.makedirs(new_dir)
	
	if path.endswith('.md'):
		new_path = new_path[:-len('md')] + 'html'
		convert(old_path, new_path)
	else:
		# images, for example
		shutil.copyfile(old_path, new_path)


def fix_link(line, root):
	if 'href=' not in line:
		return line
	
	index = line.index('href=') + len('href=')
	quote = line[index]
	index += 1
	start_index = index
	while line[index] != quote:
		index += 1
	end_index = index
	link = line[start_index : end_index]
	
	if '://' in link:
		return line
	
	name = os.path.basename(link)
	if '#' in name:
		name = name[:name.index('#')]
	name, _ext = os.path.splitext(name)
	if name not in filenames:
		return line
	
	link = root + filenames[name] + '.html'
	line = line[:start_index] + link + line[end_index:]
	return line

def fix_image(line, root):
	if 'img src=' not in line:
		return line
	
	index = line.index('img src=') + len('img src=') + 1
	line = line[:index] + root + line[index:]
	return line

def fix_line(line, root):
	line = line.decode('utf-8')
	
	line = fix_link(line, root)
	line = fix_image(line, root)
	
	line = line.encode('utf-8')
	return line


def add_my_styles(f):
	f.write(
b"""
  <style>
    code, div.sourceCode {
      background-color: #F4F4F4;
    }
    a, a:visited {
      color: #00F;
    }
    body {
      font-size: 18px;
      max-width: 50em;
      padding-left: 50px;
      padding-right: calc(50px + 280px + 10px * 2);
    }
    .sidebar {
      width: 280px;
      height: calc(100% - 20px);
      position: fixed;
      z-index: 1;
      top: 10px;
      bottom: 10px;
      right: 5px;
      border: 1px solid #000;
      border-radius: 10px;
      font-size: 14px;
      overflow-x: hidden; /* Disable horizontal scroll */
      padding: 10px;
    }
    p {
      margin: 0;
    }
  </style>
"""
	)

def add_sidebar(f, root):
	for line in sidebar_content:
		line = fix_line(line, root)
		f.write(line)

def get_sidebar_content(path):
	path = path[len(md_dir):]
	if path[0] in '/\\':
		path = path[1:]
	path = path[:-len('md')] + 'html'
	
	path = os.path.join(html_dir, path)
	f = open(path, 'rb')
	content = False
	
	res = [b'<div class="sidebar">\n']
	for line in f:
		if line.startswith(b'</body>'):
			content = False
		
		if content:
			res.append(line)
		
		if line.startswith(b'</header>'):
			content = True
	res.append(b'</div>\n')
	
	return res


def convert(old, new):
	lines = open(old, 'rb').readlines()
	tmp_file_name = '_tmp_file.md'
	f = open(tmp_file_name, 'wb')
	start_renpy_code = b'```renpy'
	start_python_code = b'```python'
	for line in lines:
		if start_renpy_code in line:
			line = line.replace(start_renpy_code, start_python_code)
		f.write(line)
	f.close()
	
	title = os.path.basename(new).replace('-', ' ')
	title = title[:-len('.html')]
	os.system('pandoc -f gfm -t html "%s" -o "%s" --highlight-style=tango -s -M title="%s"' % (tmp_file_name, new, title))
	
	os.remove(tmp_file_name)
	
	
	root = '../' * (new.count('/') - 1)
	
	lines = open(new, 'rb').readlines()
	f = open(new, 'wb')
	for line in lines:
		line = fix_line(line, root)
		f.write(line)
		
		if line.startswith(b'  </style>'):
			add_my_styles(f)
		
		if sidebar_file is None or not old.endswith(sidebar_file):
			if line.startswith(b'<body>'):
				add_sidebar(f, root)


sidebar_file = None
files = []
filenames = {}
for path, ds, fs in os.walk(md_dir):
	for f in fs:
		full_path = os.path.join(path, f)
		if f.lower().endswith('_sidebar.md'):
			sidebar_file = full_path
		else:
			files.append(full_path)
		
		if full_path.endswith('.md'):
			f = f[:-len('.md')]
			
			full_path = full_path[len(md_dir):]
			if full_path[0] in '/\\':
				full_path = full_path[1:]
			full_path = full_path[:-len('.md')]
			
			filenames[f] = full_path


sidebar_content = []
if sidebar_file is not None:
	print('0/%s: %s' % (len(files), sidebar_file))
	processing(sidebar_file)
	sidebar_content = get_sidebar_content(sidebar_file)


for i in range(len(files)):
	print('%s/%s: %s' % ((i + 1), len(files), files[i]))
	processing(files[i])
