En:
	The mod takes sprites registered in rpy-files from mods/common/
	
	You can move sprites with the mouse (the selected sprite is moved, not the one under the mouse cursor).
	By default, movement occurs along the X and Y axes, while pressing Ctrl - only along X.
	
	* Ctrl+C - copy the code that will display the current sprites.
	This function does not take on the task of setting up the as (pseudonym) and with (effect) parameters;
	
	* H - hide panels and enlarge sprite screen to normal size;
	* R - reset the parameters of the selected sprite to default values.

Ru:
	Мод берёт спрайты, зарегистрированные в rpy-файлах из mods/common/
	
	Вы можете двигать спрайты мышью (перемещается выделенный спрайт, а не тот, что под курсором мыши).
	По умолчанию передвижение происходит по осям X и Y, при нажатой Ctrl - только по X.
	
	* Ctrl+C - скопировать код, который отобразит текущие спрайты.
	Эта функция не берёт на себя задачу расставить параметры as (псевдоним) и with (эффект);
	
	* H - скрыть панели и увеличить экран спрайтов до нормального размера;
	* R - сброс параметров выделенного спрайта на значения по умолчанию.
