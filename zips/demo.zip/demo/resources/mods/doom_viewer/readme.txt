Port of https://github.com/StanislavPetrovV/DOOM-Level-Viewer for Ren-Engine.

Images are extracted from wad-file.
Places of images in the file are filled with zeros.
The file has been compressed.

Wad-file size has been reduced (4.0 -> 1.1 MB, size of images = 227 KB).
Loading time has been reduced (2.2 -> 0.16 seconds).

Other *.wad files have most likely become unavailable for loading.
