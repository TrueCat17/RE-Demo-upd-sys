[Common]
Mark on locations points to visit.

After press "Start".
Character will go from start to end point across all in-between places.


[brute_force]
Parameter <brute_force> define need to try to find the shortest path between points of one location through exit from it.


[Point selection]
You can mark point on aviable to moving (shaded) location place.
You can select location on main screen.
Use keys WASD for moving on location.
Press <Esc> for exit from location screen to main screen.
